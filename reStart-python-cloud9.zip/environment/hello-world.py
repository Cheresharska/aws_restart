print ("Hello, World")
